A Ruby module written by Mike Owens <http://mike.filespanker.com>
that wraps the Clipper library can be downloaded from:

http://github.com/mieko/rbclipper