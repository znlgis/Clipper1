
Tobias Mahlmann < t.mahlmann@gmail.com > 
has written a java translation of Clipper

http://www.lighti.de/projects/polygon-clipper-for-java/ 